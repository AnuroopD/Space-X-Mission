import { TestBed } from '@angular/core/testing';

import { GetMissionService } from './get-mission.service';

describe('GetMissionService', () => {
  let service: GetMissionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetMissionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
